import './styles/App.scss';
import RouteSeperater from './routes';

function App() {
  return (
    <div>
     <RouteSeperater/>
    </div>
  );
}

export default App;
